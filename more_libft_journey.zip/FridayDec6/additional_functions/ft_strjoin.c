/*
To implement the function ft_substr according to the provided specification, we need to create a substring from a given string s, starting at a specified index start and with a maximum length of len. 
	If the allocation fails, we should return NULL.

Here's a step-by-step breakdown of how to implement this function in C:

    Check for Valid Input: Ensure that the string s is not NULL and that the start index is within the bounds of the string.

    Calculate the Length of the Substring: Determine the actual length of the substring to be copied. This will be the minimum of len and the remaining length of the string from the start index.

    Allocate Memory: Use malloc to allocate memory for the substring. Remember to allocate an extra byte for the null terminator.

    Copy the Substring: Use a loop or a function like strncpy to copy the substring from s to the newly allocated memory.

    Return the Result: Return the pointer to the newly created substring.

*/

