#include <stdio.h>
#include <stdlib.h>
#include "libft.h" // Make sure this header file contains the definition of t_list and ft_lstnew

// Mock malloc to simulate allocation failure
void *mock_malloc(size_t size) {
    return NULL; // Simulate allocation failure
}

int main() {
    // Test 1: Create a new node with an integer
    int *value1 = malloc(sizeof(int));
    *value1 = 42; // Assign a value
    t_list *node1 = ft_lstnew(value1);
    
    if (node1) {
        printf("Node 1 created with content: %d\n", *(int *)node1->content);
    } else {
        printf("Failed to create Node 1\n");
    }

    // Test 2: Create a new node with another integer
    int *value2 = malloc(sizeof(int));
    *value2 = 84; // Assign a value
    t_list *node2 = ft_lstnew(value2);
    
    if (node2) {
        printf("Node 2 created with content: %d\n", *(int *)node2->content);
    } else {
        printf("Failed to create Node 2\n");
    }

    // Test 3: Create a new node with NULL content
    t_list *node3 = ft_lstnew(NULL);
    
    if (node3) {
        printf("Node 3 created with NULL content\n");
    } else {
        printf("Failed to create Node 3\n");
    }

    // Test 4: Simulate allocation error
    printf("\nSimulating allocation error...\n");
    // Temporarily override malloc
    void *(*original_malloc)(size_t) = malloc; // Save original malloc
    malloc = mock_malloc; // Override malloc to simulate failure

    t_list *node4 = ft_lstnew(value1); // Attempt to create a new node
    if (node4) {
        printf("Node 4 created with content: %d\n", *(int *)node4->content);
    } else {
        printf("Failed to create Node 4 due to allocation error\n");
    }

    // Restore original malloc
    malloc = original_malloc;

    // Clean up: Free the allocated nodes and their contents
    free(node1->content); // Free the content of node1
    free(node1);          // Free the node itself
    free(node2->content); // Free the content of node2
    free(node2);          // Free the node itself
    free(node3);          // Free node3 (content is NULL, so no need to free it)

    return 0;
}
