
#include "libft.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char *ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*substr;
	size_t		s_len;
	size_t		i;
	
	i = 0;
	if (!s)
		return (NULL);
	s_len = ft_strlen(s);
	if (start >= s_len)
		return (ft_strdup(""));
	if (len > s_len - start)
		len = s_len - start;
	substr = (char *) malloc(len +1);
	if (!substr)
		return NULL; // Allocation faled!
	while (i < len)
	{	
		substr[i] = s[start +i];
		i++;
	}
	//Null-terminate
	substr[len] = '\0';
	return (substr);
}

#include "libft.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main() {
    char *result;

    // Test with a normal string
    result = ft_substr("Hello, World!", 7, 5);
    printf("Result 1: '%s'\n", result); // Should print 'World'
    free(result);

    // Test with start index out of bounds
    result = ft_substr("Hello, World!", 20, 5);
    printf("Result 2: '%s'\n", result); // Should print ''
    free(result);

    // Test with length exceeding remaining string length
    result = ft_substr("Hello, World!", 7, 20);
    printf("Result 3: '%s'\n", result); // Should print 'World!'
    free(result);

    // Test with null string
    result = ft_substr(NULL, 0, 5);
    if (result == NULL) {
        printf("Result 4: '(null)'\n"); // Handle NULL case
    } else {
        printf("Result 4: '%s'\n", result);
        free(result);
    }

    // Test with empty string
    result = ft_substr("", 0, 5);
    printf("Result 5: '%s'\n", result); // Should print ''
    free(result);

    return 0;
}
