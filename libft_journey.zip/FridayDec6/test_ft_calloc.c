//#include <stdio.h>
//#include <stdlib.h>
//#include <string.h> // For memset
#include "libft.h"

void	*ft_calloc(size_t count, size_t size)
{
	//Work out total size required
	size_t		size_total;
	
	size_total = size * count;
	
	//Allocat mem
	void *ptr = malloc(size_total);
	
	if (ptr == NULL)
		return NULL;
		
	// Init allocated mem with zero
	//ft_memset(ptr, 0, size_total);
	memset(ptr, 0, size_total);
}
