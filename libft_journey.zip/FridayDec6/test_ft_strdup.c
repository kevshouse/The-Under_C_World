#include "libft.h"

// uses malloc() and strcpy().
// User must free memory when nolonger required.
// If input = NULL, behaviour not defined!
// const char *s defines a pointer to the NUll termed
// string that should be duplicated.
/* Behaviour: The function will allocate enough mem to hold
the original string, including the null terminator.
Function copies the source string into the newly allocated memory.
To avoid memory leaks, memory allocated by strdup() must be freed,
strdup() can´t free it! 

*/


char *ft_strdup(const char *s)
{
//calculate size of source string in bytes (including null term),
//assign an size_t var and set it to size of source. 
// malloc the mem according to size above.
// strcpy the source to allocated memory location.
//return pointer of allocated memory.
	size_t		buffer_size;
	char		*ptr;
	
	buffer_size = (sizeof(char) * (ft_strlen(s)+1));
	ptr = malloc(buffer_size);
	strcpy(ptr, s);
	return(ptr);
}
/*
#include <stdio.h>


int main() {

    const char *original = "Hello, World!";

    char *duplicate = ft_strdup(original);


    if (duplicate != NULL) {

        printf("Original: %s\n", original);

        printf("Duplicate: %s\n", duplicate);

        free(duplicate); // Free the allocated memory

    } else {

        printf("Memory allocation failed.\n");

    }


    return 0;

}
*/
